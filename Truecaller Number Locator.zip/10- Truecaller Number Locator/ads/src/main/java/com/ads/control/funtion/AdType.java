package com.ads.control.funtion;

public enum AdType {
    BANNER,
    INTERSTITIAL,
    NATIVE,
    REWARDED,
    APP_OPEN
}
