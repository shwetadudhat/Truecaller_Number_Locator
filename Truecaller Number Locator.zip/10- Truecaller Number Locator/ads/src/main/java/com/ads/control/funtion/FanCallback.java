package com.ads.control.funtion;

import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeBannerAd;

public class FanCallback {
    public FanCallback() {
    }

    public void onAdClosed() {
    }

    public void onAdFailedToLoad(AdError adError) {
    }

    public void onAdOpened() {
    }

    public void onAdLoaded() {
    }

    public void onInterstitialLoad() {

    }

    public void onAdClicked() {
    }

    public void onAdImpression() {
    }

    public void onNativeAdLoaded(NativeAd nativeAd) {
    }

    public void onNativeBannerAdLoaded(NativeBannerAd nativeAd) {
    }

}
