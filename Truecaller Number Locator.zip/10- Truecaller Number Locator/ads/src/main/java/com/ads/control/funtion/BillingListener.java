package com.ads.control.funtion;

import android.content.Intent;

public interface BillingListener {
    void onInitBillingFinished(int resultCode);
}
