package com.ads.control.ads;

public interface AperoInitCallback {
    void initAdSuccess();
}
