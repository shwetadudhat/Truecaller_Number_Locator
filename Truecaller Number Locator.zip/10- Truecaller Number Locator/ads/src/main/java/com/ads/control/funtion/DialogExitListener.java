package com.ads.control.funtion;

public interface DialogExitListener {
    void onExit(boolean exit);
}
