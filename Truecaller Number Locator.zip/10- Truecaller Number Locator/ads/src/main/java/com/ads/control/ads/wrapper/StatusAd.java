package com.ads.control.ads.wrapper;

public enum StatusAd {
    AD_INIT,AD_LOADING, AD_LOADED, AD_LOAD_FAIL, AD_RENDER_SUCCESS
}
