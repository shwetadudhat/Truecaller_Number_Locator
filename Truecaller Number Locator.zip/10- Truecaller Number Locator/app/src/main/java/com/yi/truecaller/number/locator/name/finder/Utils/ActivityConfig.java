package com.yi.truecaller.number.locator.name.finder.Utils;

public class ActivityConfig {

    //Replace this AdUnits IDs with your own Facebook App AdUnits
    public static String FB_NATIVE = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static String FB_BANNER_50 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static String FB_BANNER_90 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static String FB_RECTANGLE = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static String FB_INTERSTITIAL = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static String FB_REWARD = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";

}