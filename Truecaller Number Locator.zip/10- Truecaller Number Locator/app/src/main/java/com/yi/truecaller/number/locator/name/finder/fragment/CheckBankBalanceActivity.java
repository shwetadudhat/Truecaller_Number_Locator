package com.yi.truecaller.number.locator.name.finder.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.nativead.NativeAd;
import com.yi.truecaller.number.locator.name.finder.Base.BaseActivity;
import com.yi.truecaller.number.locator.name.finder.R;

public class CheckBankBalanceActivity extends BaseActivity
{
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.checkbankbalance_activity);

        TextView textView = findViewById(R.id.text);
        textView.setText(getIntent().getStringExtra("bankName"));

        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        String enQuiry = getIntent().getStringExtra("enquiry");
        String customerCare = getIntent().getStringExtra("customer");

        TextView enquiryCall = findViewById(R.id.balanceNumber);
        TextView customerCall = findViewById(R.id.customerNumber);

        enquiryCall.setText(enQuiry);
        customerCall.setText(customerCare);
        loadNative();
    }

    public void loadNative() {
        MobileAds.initialize(this);
        AdLoader adLoader = new AdLoader.Builder(this, getString(R.string.check_balance_native))
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        NativeTemplateStyle styles = new
                                NativeTemplateStyle.Builder().build();
                        TemplateView my_template_small = findViewById(R.id.my_template_small);
                        my_template_small.setStyles(styles);
                        my_template_small.setNativeAd(nativeAd);
                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
