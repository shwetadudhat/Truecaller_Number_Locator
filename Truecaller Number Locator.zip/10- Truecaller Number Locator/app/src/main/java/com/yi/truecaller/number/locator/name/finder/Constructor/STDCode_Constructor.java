package com.yi.truecaller.number.locator.name.finder.Constructor;

public class STDCode_Constructor {
    private String areacode;
    private String areaname;

    public String getAreacode() {
        return this.areacode;
    }

    public void setAreacode(String str) {
        this.areacode = str;
    }

    public String getAreaname() {
        return this.areaname;
    }

    public void setAreaname(String str) {
        this.areaname = str;
    }
}
