package com.yi.truecaller.number.locator.name.finder.Constructor;

public class ISDCode_Constructor {
    private String sg_empid;
    private String sg_firstname;

    public String getEmpId() {
        return this.sg_empid;
    }

    public void setEmpId(String str) {
        this.sg_empid = str;
    }

    public String getFirstName() {
        return this.sg_firstname;
    }

    public void setFirstName(String str) {
        this.sg_firstname = str;
    }
}
